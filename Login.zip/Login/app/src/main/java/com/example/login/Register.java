package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.idnp2024a.loginsample.R;

public class Register extends AppCompatActivity {
    private EditText edtNombres, edtApellidos, edtCorreo, edtContra, edtCelular;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edtNombres = findViewById(R.id.edtNombres);
        edtApellidos = findViewById(R.id.edtApellidos);
        edtCorreo = findViewById(R.id.edtCorreo);
        edtContra = findViewById(R.id.edtContra);
        edtCelular = findViewById(R.id.edtCelular);

        Button btnRegistrar = findViewById(R.id.btnRegistrar);

        Button btnCancelar = findViewById(R.id.btnCancelar);

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (camposCompletos()) {
                    mostrarMensaje("¡Usuario registrado!");
                } else {
                    mostrarMensaje("Complete todos los campos");
                }
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Register.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private boolean camposCompletos() {
        String nombres = edtNombres.getText().toString().trim();
        String apellidos = edtApellidos.getText().toString().trim();
        String correo = edtCorreo.getText().toString().trim();
        String contraseña = edtContra.getText().toString().trim();
        String celular = edtCelular.getText().toString().trim();

        return !TextUtils.isEmpty(nombres) &&
                !TextUtils.isEmpty(apellidos) &&
                !TextUtils.isEmpty(correo) &&
                !TextUtils.isEmpty(contraseña) &&
                !TextUtils.isEmpty(celular);
    }
    private void mostrarMensaje(String mensaje) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
}
